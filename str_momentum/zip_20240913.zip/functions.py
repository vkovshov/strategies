import sys
import os
import pandas as pd
import numpy as np
sys.path.append(os.path.abspath('../fin_data'))
from utils.postgresql_data_query import get_ranks

def trend_filter(df, _c, fast=64, med=128, slow=256, min_exp=0.5, med_exp=0.75, max_exp=1.0):
    # Calculate the moving averages
    ma_fast = df[_c].ewm(span=fast,min_periods=fast).mean()
    ma_med = df[_c].ewm(span=med,min_periods=med).mean()
    ma_slow = df[_c].ewm(span=slow,min_periods=slow).mean()
    px = df[_c]

    # Apply the conditional logic for 50-day moving average
    filtered_ma_fast = ma_fast.where((ma_fast >= ma_slow) & (ma_fast >= ma_med), ma_slow)
    
    # Apply the conditional logic for 100-day moving average
    filtered_ma_med = ma_med.where(ma_med >= ma_slow, ma_slow)

    # Calculate exposure based on the conditions
    conditions = [
        (px < ma_slow),
        (px >= ma_slow) & (px < filtered_ma_med),
        (px >= filtered_ma_med) & (px < filtered_ma_fast),
        (px >= filtered_ma_fast)
    ]
    
    # Define the corresponding exposure levels
    exposure_values = [0, min_exp, med_exp, max_exp]
    
    # Apply the exposure levels
    exposure = np.select(conditions, exposure_values, default=0)

    # Combine the results into a DataFrame
    trend_indicators = pd.DataFrame({
        'exposure_date': df['Date'],
        'filtered_ma_fast': filtered_ma_fast,
        'filtered_ma_med': filtered_ma_med,
        'ma_slow': ma_slow,
        'px': px,
        'exposure': exposure
    })

    return exposure #, trend_indicators

def position_size_atr(account_value, risk_factor, exposure, atr):
    """
    Calculate position size using account value, risk factor, and ATR.

    Parameters:
    df (DataFrame): DataFrame containing the ATR values.
    account_value (float): Total account value.
    risk_factor (float): Percentage of account value to risk on each position.
    atr_column (str): Column name of ATR values in the DataFrame.

    Returns:
    Series: Position sizes for each stock.
    """
    position_size = (account_value * exposure * risk_factor) / atr
    return position_size

def vola_position_size(hist, max_positions=None):
    """
    Calculate position sizes using inverse volatility.

    Parameters:
    hist (DataFrame): Historical price data for the portfolio of stocks.
    max_positions (int, optional): Maximum number of positions to hold.

    Returns:
    Series: Target position weights for each stock.
    """
    # Calculate volatility for each stock (assumes daily returns are in hist)
    vola_table = hist.apply(lambda x: x.pct_change().std())

    # Calculate inverse volatility
    inv_vola_table = 1 / vola_table

    # Normalize to get target weights
    sum_inv_vola = np.sum(inv_vola_table)
    vola_target_weights = inv_vola_table / sum_inv_vola

    # If a maximum number of positions is specified, adjust the portfolio
    if max_positions is not None:
        sorted_weights = vola_target_weights.sort_values(ascending=False)
        selected_weights = sorted_weights.iloc[:max_positions]
        selected_weights /= selected_weights.sum()  # Normalize again
        return selected_weights

    return vola_target_weights

def process_universe_factors(eff_date, pr_date, lo_rank, hi_rank, model_factors, factor_cols):
    # Get universe factor ranks for both dates
    ranks_eff = get_ranks([eff_date], lo_rank, hi_rank, factors=model_factors).reset_index()
    ranks_pr = get_ranks([pr_date], lo_rank, hi_rank, factors=model_factors).reset_index()
    
    # Merge the ranks from both dates
    ranks = pd.merge(ranks_eff, ranks_pr, on=['ticker', 'factor_definition_id'], 
                     suffixes=('_eff', '_pr'), how='outer')
    
    # Create a new 'rank' and 'factor_date' columns that prioritize eff_date data
    ranks['rank'] = ranks['rank_eff'].combine_first(ranks['rank_pr'])
    ranks['factor_date'] = ranks['factor_date_eff'].combine_first(ranks['factor_date_pr'])
    
    # Filter out rows where ranks came from different dates to ensure consistency
    ranks = ranks.dropna(subset=['rank_eff'])\
                 .drop(['rank_pr', 'rank_eff', 'factor_date_pr', 'factor_date_eff'], axis=1)\
                 .reset_index(drop=True)[factor_cols]
    
    # Pivot the DataFrame so that each ticker has a single row with factors as columns
    ranks_pivoted = ranks.pivot_table(index=['ticker', 'factor_date'], 
                                      columns='factor_definition_id', 
                                      values='rank')
    
    # Rename columns for clarity, sort by ticker, date and reindex
    ranks_pivoted.columns.name = None
    ranks_pivoted.columns = [f'f_{col}' if isinstance(col, int) else col for col in ranks_pivoted.columns]
    ranks = ranks_pivoted.sort_values(by=['ticker', 'factor_date']).reset_index(drop=False)
    
    print(f'Test universe: {len(ranks)}')
    return ranks

def signal_filter(df, _h, _l, _c, n, pct_change_threshold=0.15, period=90):
    """
    Generate a trading signal based on the closing price and a simple moving average (SMA),
    with an additional check for whether the stock moved more than a certain percentage
    up or down in the last `period` days.
    Returns:
    - signal_value: 1 if the last close > SMA and no significant move detected in the last `period` days, otherwise 0
    """

    # Calculate the simple moving average (SMA)
    df['EMA'] = df[_c].ewm(span=n,min_periods=n).mean()

    # Consider the last `period` days to exclude any big moves
    df['big_move'] = (
    ((df[_l] / df[_h].shift(2)).abs() - 1 >= pct_change_threshold) | 
    ((df[_h] / df[_l].shift(2)).abs() - 1 >= pct_change_threshold)).astype(int)

    last_period_big_move = df['big_move'].iloc[-period:].max()

    # Generate the signal: 1 if last close > SMA and no big move in the last `period` days, otherwise 0
    signal_value = 0
    if not df.empty and not df['EMA'].isna().iloc[-1]:
        last_close = df[_c].iloc[-1]
        last_ema = df['EMA'].iloc[-1]

        # Check that there has not been a significant move in the last `period` days
        signal_value = 1 if (last_close > last_ema) and (last_period_big_move == 0) else 0

    return signal_value

def select_positions_1(df, max_exposure=1, max_sector_allocation=0.2): # no priority to 'new' positions
    selected_positions = []
    total_exposure = 0.0
    sector_allocations = {}

    for index, row in df.iterrows():
        position_pct = row['pct_position']
        sector = row['sector']
        
        # Calculate the potential new sector allocation
        new_sector_allocation = sector_allocations.get(sector, 0) + position_pct
        
        # Check if adding this position would exceed the sector allocation limit or total exposure
        if new_sector_allocation <= max_sector_allocation and (total_exposure + position_pct) <= max_exposure:
            selected_positions.append(row)
            total_exposure += position_pct
            sector_allocations[sector] = new_sector_allocation
            
            # Stop if we've reached the maximum allowed exposure
            if total_exposure >= max_exposure:
                break

    # Convert the selected positions list back to a DataFrame
    selected_df = pd.DataFrame(selected_positions)
    return selected_df

def select_positions_2(df, max_exposure=1, max_sector_allocation=0.2): # priority is given to 'new' positions
    selected_positions = []
    total_exposure = 0.0
    sector_allocations = {}

    def try_select_position(row):
        nonlocal total_exposure, sector_allocations
        position_pct = row['pct_position']
        sector = row['sector']
        
        # Calculate the potential new sector allocation
        new_sector_allocation = sector_allocations.get(sector, 0) + position_pct
        
        # Check if adding this position would exceed the sector allocation limit or total exposure
        if new_sector_allocation <= max_sector_allocation and (total_exposure + position_pct) <= max_exposure:
            selected_positions.append(row)
            total_exposure += position_pct
            sector_allocations[sector] = new_sector_allocation
            
            # Stop if we've reached the maximum allowed exposure
            return total_exposure >= max_exposure
        return False

    # First pass: prioritize 'new' positions
    for index, row in df[df['label'] == 'new'].iterrows():
        if try_select_position(row):
            break

    # Second pass: go through the entire DataFrame (which will include both 'new' and 'old' positions)
    for index, row in df.iterrows():
        if row['label'] != 'new':  # Skip 'new' positions that have already been considered
            if try_select_position(row):
                break

    # Convert the selected positions list back to a DataFrame
    selected_df = pd.DataFrame(selected_positions)
    return selected_df

def exposure_summary(df, group_keys=['sector', 'industry', 'ticker', 'name'], 
                     aggregate_by='exposure', 
                     round_val=2, format_str='{:.02f}'):
    
    # Group by the specified keys and calculate the sum for the exposure
    summary_df = df.groupby(group_keys)['pct_position'].sum().reset_index()
    
    # Rename the aggregated column to 'exposure'
    summary_df.rename(columns={'pct_position': aggregate_by}, inplace=True)
    
    # Additional aggregation for sector and industry levels
    sector_agg = summary_df.groupby('sector')[aggregate_by].sum().reset_index().rename(columns={aggregate_by: 'sector_exp'})
    industry_agg = summary_df.groupby(['sector', 'industry'])[aggregate_by].sum().reset_index().rename(columns={aggregate_by: 'industry_exp'})
    
    # Merge the sector and industry exposures back to the summary DataFrame
    summary_df = summary_df.merge(sector_agg, on='sector')
    summary_df = summary_df.merge(industry_agg, on=['sector', 'industry'])
    
    # Sort by sector_exp, industry_exp, and exposure
    summary_df = summary_df.sort_values(by=['sector_exp', 'sector', 'industry_exp', 'industry', aggregate_by, 'ticker', 'name'], 
                                        ascending=[False, True, False, True, False, True, True]).round(round_val)
    
    # Reorder columns to have the name column at the end
    ordered_columns = ['sector', 'sector_exp', 'industry', 'industry_exp', 'ticker', aggregate_by, 'name']
    summary_df = summary_df[ordered_columns]
    
    # Reset index and calculate the total exposure
    summary_df = summary_df.reset_index(drop=True)
    total_exposure = round(summary_df[aggregate_by].sum(), round_val)
    print(f'Total exposure: {total_exposure}')
    
    # Apply the background gradient to the exposure columns and format them
    exposure_cols = ['sector_exp', 'industry_exp', aggregate_by]
    summary_df_styled = summary_df.style.background_gradient(subset=exposure_cols, cmap='RdYlGn').format({col: format_str for col in exposure_cols})
    
    return summary_df_styled

def filter_ranks(df):
    filter_1 = df[(df['f_85'] > 85) & (df['f_86'] >= 80) & (df['f_85'] >= df['f_86'])].copy()
    filter_1 = filter_1.sort_values(by=['f_85', 'f_86'], ascending=False)
    
    filter_2 = df[(df['f_85'] > 80) & (df['f_86'] >= 70)].copy()
    filter_2 = filter_2.sort_values(by=['f_85', 'f_86'], ascending=False)
    
    filter_3 = df[(df['f_86'] > 90) & (df['f_85'] > 80)].copy()
    filter_3 = filter_3.sort_values(by=['f_86', 'f_85'], ascending=False)
    
    return filter_1